sap.ui.define(["sap/fe/core/AppComponent"],function(e){return e.extend("sap.capire.travels.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map